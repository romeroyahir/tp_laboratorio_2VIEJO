﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Numero
    {
        #region Atributos
        /// <summary>
        /// Atributos
        /// </summary>
        private double numero;
        #endregion

        #region Constructores
        /// <summary>
        /// Constructores
        /// </summary>
        public Numero()
        {
            this.numero = 0;
        }

        public Numero(string numero)
        {
            this.numero = ValidarNumero(numero);
        }

        public Numero(double numero)
            //:this(numero)
        {
            this.numero = numero;
        }


        #endregion

        #region Get & Set
        /// <summary>
        /// Metodo SetNumero, se asigna y valida valor ingresado y retorna como double.
        /// </summary>
        /// <param name="_numero"></param>
        private void SetNumero(string _numero)
        {
            this.numero = ValidarNumero(_numero);
        }
        //public double GetNumero()
        //{ }
        #endregion

        /// <summary>
        /// Metodo ValidarNumero para evitar que en caso de división, el denominador sea 0.
        /// </summary>
        /// <param name="numeroString"></param>
        /// <returns>Valor Numero (Double)</returns>
        private double ValidarNumero(string numeroString)
        {
            double num = 0;
            if (double.TryParse(numeroString, out num) == true)
            {
                return num;
            }
            else
            {
                return num;
            }
            
        }

        #region Operadores Unarios (Suma, resta, multiplicacion, division)
        /// <summary>
        /// Operador de suma entre dos objetos Numero
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns>Resultado de operacion (Double)</returns>
        public static double operator + (Numero num1, Numero num2)
        {
            double resultado;
            resultado = num1.numero + num2.numero;
            return resultado;
        }
        
        /// <summary>
        /// Operador - entre dos objetos Numero
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns>Resultado de operacion (Double)</returns>
        public static double operator -(Numero num1, Numero num2)
        {
            double resultado;
            resultado = num1.numero - num2.numero;
            return resultado;
        }

        /// <summary>
        /// Operador * entre dos objetos Numero
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns>Resultado de operacion (Double)</returns>
        public static double operator *(Numero num1, Numero num2)
        {
            double resultado;
            resultado = num1.numero * num2.numero;
            return resultado;
        }

        /// <summary>
        /// Operador / entre dos objetos Numero
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns>Resultado de operacion (Double)</returns>
        public static double operator /(Numero num1, Numero num2)
        {
            double resultado;

            resultado = num1.numero / num2.numero;
            return resultado;
        }
        #endregion

        #region Operadores Comparacion
        /// <summary>
        /// Bool operators == y != entre objeto Numero y valor INT.
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns>True (Dada la igualdad), False (caso contrario)</returns>
        public static bool operator ==(Numero num1, int num2)
        {
            if (num1.numero == num2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator !=(Numero num1, int num2)
        {
            return !(num1 == num2);
        }
        #endregion
    }
}
